﻿namespace Aprohirdetes.Models
{
    public class aprohirdetes
    {
        public int id { get; set; }
        public string cim { get; set; }
        public string leiras { get; set; }
        public DateTime megjelenesdatum { get; set; }
        public string helyszin { get; set; }
        public string email { get; set; }
        public Boolean aktualis { get; set; }
    }
}
