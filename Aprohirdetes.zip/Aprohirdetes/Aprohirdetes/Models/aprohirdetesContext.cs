﻿using Microsoft.EntityFrameworkCore;

namespace Aprohirdetes.Models
{
    public class aprohirdetesContext : DbContext
    {
        public string conn = "server=localhost;userid=root;database=aprohirdetes;";

        public DbSet<aprohirdetes> aprohirdetes { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(conn, ServerVersion.AutoDetect(conn));
        }
    }
}
