using Aprohirdetes.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Cryptography.X509Certificates;

namespace Aprohirdetes.Pages
{
    public class IndexModel : PageModel
    {
        public aprohirdetesContext db;
        public IndexModel(aprohirdetesContext x)
        {
            db = x;
            db.Database.EnsureCreated();
        }
        public void OnGet()
        {
        }
    }
}
