using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Aprohirdetes.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
