using Aprohirdetes.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Aprohirdetes.Pages
{
    public class felveszModel : PageModel
    {
        public static aprohirdetesContext db;
        public felveszModel(aprohirdetesContext x)
        {
            db = x;
        }
        public void OnGet()
        {
        }
        public void OnPost() 
        {
            string cim = Request.Form["cim"];
            string leiras = Request.Form["leiras"];
            string helyszin = Request.Form["helyszin"];
            string email = Request.Form["email"];
            DateTime datum=DateTime.Now;
            Boolean aktualitas = true;

            db.aprohirdetes.Add(new aprohirdetes { cim = cim, leiras = leiras, helyszin = helyszin, email = email, aktualis = aktualitas, megjelenesdatum = datum });
            db.SaveChanges();


        }    
    }
}
